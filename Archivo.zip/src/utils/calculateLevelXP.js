module.exports = (level) => {
    return 100 * (level || 1);
  };
  