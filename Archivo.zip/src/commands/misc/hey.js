module.exports = {
    name: 'hey',
    description: 'Replies with Hey!',
    callback: (client, interaction) => {
      interaction.reply('Hey!');
    },
  };
  